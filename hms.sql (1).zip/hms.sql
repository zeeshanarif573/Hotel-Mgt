--
-- Database: `hms`
--

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `Customer_ID` int(11) NOT NULL,
  `First_Name` varchar(15) NOT NULL,
  `Last_Name` varchar(15) NOT NULL,
  `Email` varchar(25) NOT NULL,
  `Password` int(11) NOT NULL,
  `Address` varchar(100) NOT NULL,
  `Country` varchar(10) NOT NULL,
  `Phone_No` int(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`Customer_ID`, `First_Name`, `Last_Name`, `Email`, `Password`, `Address`, `Country`, `Phone_No`) VALUES
(7, 'Mujeeb', 'Ahmed', 'mujeeb@yahoo.com', 1313, 'flat # 4', 'Pakistan', 2147483647),
(8, 'Muhammad', 'Zeeshan', 'zeeshanarif573@gmail.com', 1212, 'house # 12', 'Pakistan', 2147483647);

-- --------------------------------------------------------

--
-- Table structure for table `room`
--

CREATE TABLE `room` (
  `Room_ID` int(11) NOT NULL,
  `Number_of_Rooms` int(11) NOT NULL,
  `Room_Number` int(11) NOT NULL,
  `Customer_ID` int(11) NOT NULL,
  `Check_In` date NOT NULL,
  `Check_Out` date NOT NULL,
  `Room_Type` varchar(15) NOT NULL,
  `Room_Amount` int(11) NOT NULL,
  `Status` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `room`
--

INSERT INTO `room` (`Room_ID`, `Number_of_Rooms`, `Room_Number`, `Customer_ID`, `Check_In`, `Check_Out`, `Room_Type`, `Room_Amount`, `Status`) VALUES
(113, 2, 5, 7, '2016-11-13', '2016-11-18', 'Diamond', 4500, ' Active '),
(114, 2, 9, 7, '2016-11-12', '2016-11-22', 'Silver', 8000, ' Active ');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`Customer_ID`);

--
-- Indexes for table `room`
--
ALTER TABLE `room`
  ADD PRIMARY KEY (`Room_ID`),
  ADD KEY `Customer_ID` (`Customer_ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `customer`
--
ALTER TABLE `customer`
  MODIFY `Customer_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `room`
--
ALTER TABLE `room`
  MODIFY `Room_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=115;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `room`
--
ALTER TABLE `room`
  ADD CONSTRAINT `room_ibfk_1` FOREIGN KEY (`Customer_ID`) REFERENCES `customer` (`Customer_ID`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
