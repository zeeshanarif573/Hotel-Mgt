--
-- Database: `hms`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `Admin_ID` int(11) NOT NULL,
  `Admin_Name` varchar(15) NOT NULL,
  `Username` varchar(20) NOT NULL,
  `Password` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`Admin_ID`, `Admin_Name`, `Username`, `Password`) VALUES
(3, 'Saad', 'saad@hotmail.com', '2222'),
(5, 'Ahsan', 'ahsan@yahoo.com', '8787');

-- --------------------------------------------------------

--
-- Table structure for table `booking`
--

CREATE TABLE `booking` (
  `Booking_ID` int(11) NOT NULL,
  `Room_ID` int(11) DEFAULT NULL,
  `Customer_ID` int(11) NOT NULL,
  `Check_In` date NOT NULL,
  `Check_Out` date NOT NULL,
  `Number_of_Rooms` int(11) DEFAULT NULL,
  `Room_Amount` int(11) NOT NULL,
  `Total_Amount` bigint(20) NOT NULL,
  `Status` varchar(10) NOT NULL,
  `Request` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `booking`
--

INSERT INTO `booking` (`Booking_ID`, `Room_ID`, `Customer_ID`, `Check_In`, `Check_Out`, `Number_of_Rooms`, `Room_Amount`, `Total_Amount`, `Status`, `Request`) VALUES
(103, 1, 27, '2016-11-09', '2016-11-26', 1, 17000, 0, '', ''),
(104, 1, 27, '2016-11-16', '2016-11-26', 1, 10000, 0, '', ''),
(105, 2, 27, '2016-11-23', '2016-11-26', 1, 2700, 0, '', ''),
(125, 2, 26, '2016-11-09', '2016-11-26', 1, 15300, 0, '', '');

-- --------------------------------------------------------

--
-- Table structure for table `car_hire`
--

CREATE TABLE `car_hire` (
  `Car_ID` int(11) NOT NULL,
  `Customer_ID` int(11) NOT NULL,
  `Booking_ID` int(11) NOT NULL,
  `Selected_Car` varchar(15) NOT NULL,
  `From_Date` date NOT NULL,
  `To_Date` date NOT NULL,
  `Car_Charges` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `car_hire`
--

INSERT INTO `car_hire` (`Car_ID`, `Customer_ID`, `Booking_ID`, `Selected_Car`, `From_Date`, `To_Date`, `Car_Charges`) VALUES
(21, 27, 103, 'BMW', '2016-11-16', '2016-11-25', 4050);

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `Customer_ID` int(11) NOT NULL,
  `First_Name` varchar(15) NOT NULL,
  `Last_Name` varchar(15) NOT NULL,
  `Email` varchar(25) NOT NULL,
  `Password` bigint(11) NOT NULL,
  `Address` varchar(100) NOT NULL,
  `Country` varchar(10) NOT NULL,
  `Cell_Number` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`Customer_ID`, `First_Name`, `Last_Name`, `Email`, `Password`, `Address`, `Country`, `Cell_Number`) VALUES
(26, 'Afreen', 'Malik', 'afreen@gmail.com', 4444, 'house # 12', 'Pakistan', 2136649631),
(27, 'Asad', 'Ali', 'asad@gmail.com', 1111, 'house # 12', 'Pakistan', 2147483647);

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE `feedback` (
  `Visitor_ID` int(11) NOT NULL,
  `Name` varchar(15) NOT NULL,
  `Email` varchar(20) NOT NULL,
  `Message` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`Visitor_ID`, `Name`, `Email`, `Message`) VALUES
(2, 'Haroon', 'haroon123@gmail.com', 'Hi Haroon is here!');

-- --------------------------------------------------------

--
-- Table structure for table `room`
--

CREATE TABLE `room` (
  `Room_ID` int(11) NOT NULL,
  `Room_Name` varchar(10) NOT NULL,
  `Room_Price` bigint(20) NOT NULL,
  `Total_Rooms` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `room`
--

INSERT INTO `room` (`Room_ID`, `Room_Name`, `Room_Price`, `Total_Rooms`) VALUES
(1, 'DELUXE', 1000, 10),
(2, 'DIAMOND', 900, 10),
(3, 'SILVER', 800, 10);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`Admin_ID`);

--
-- Indexes for table `booking`
--
ALTER TABLE `booking`
  ADD PRIMARY KEY (`Booking_ID`),
  ADD KEY `Customer_ID` (`Customer_ID`),
  ADD KEY `Room_ID` (`Room_ID`);

--
-- Indexes for table `car_hire`
--
ALTER TABLE `car_hire`
  ADD PRIMARY KEY (`Car_ID`),
  ADD KEY `Customer_ID` (`Customer_ID`),
  ADD KEY `Booking_ID` (`Booking_ID`);

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`Customer_ID`);

--
-- Indexes for table `feedback`
--
ALTER TABLE `feedback`
  ADD PRIMARY KEY (`Visitor_ID`);

--
-- Indexes for table `room`
--
ALTER TABLE `room`
  ADD PRIMARY KEY (`Room_ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `Admin_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `booking`
--
ALTER TABLE `booking`
  MODIFY `Booking_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=126;
--
-- AUTO_INCREMENT for table `car_hire`
--
ALTER TABLE `car_hire`
  MODIFY `Car_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;
--
-- AUTO_INCREMENT for table `customer`
--
ALTER TABLE `customer`
  MODIFY `Customer_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;
--
-- AUTO_INCREMENT for table `feedback`
--
ALTER TABLE `feedback`
  MODIFY `Visitor_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `room`
--
ALTER TABLE `room`
  MODIFY `Room_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `booking`
--
ALTER TABLE `booking`
  ADD CONSTRAINT `booking_ibfk_1` FOREIGN KEY (`Customer_ID`) REFERENCES `customer` (`Customer_ID`),
  ADD CONSTRAINT `booking_ibfk_2` FOREIGN KEY (`Room_ID`) REFERENCES `room` (`Room_ID`);

--
-- Constraints for table `car_hire`
--
ALTER TABLE `car_hire`
  ADD CONSTRAINT `car_hire_ibfk_1` FOREIGN KEY (`Customer_ID`) REFERENCES `customer` (`Customer_ID`),
  ADD CONSTRAINT `car_hire_ibfk_2` FOREIGN KEY (`Booking_ID`) REFERENCES `booking` (`Booking_ID`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
