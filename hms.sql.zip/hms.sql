--
-- Database: `hms`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `Admin_ID` int(11) NOT NULL,
  `Admin_Name` varchar(15) NOT NULL,
  `Username` varchar(40) NOT NULL,
  `Password` bigint(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`Admin_ID`, `Admin_Name`, `Username`, `Password`) VALUES
(3, 'Saad', 'saad@hotmail.com', 2222),
(5, 'Ahsan', 'ahsan@yahoo.com', 8787),
(9, 'Zeeshan', 'zeeshanarif573@gmail.com', 5555);

-- --------------------------------------------------------

--
-- Table structure for table `booking`
--

CREATE TABLE `booking` (
  `Booking_ID` int(11) NOT NULL,
  `Room_ID` int(11) DEFAULT NULL,
  `Customer_ID` int(11) NOT NULL,
  `Check_In` date NOT NULL,
  `Check_Out` date NOT NULL,
  `Number_of_Rooms` int(11) DEFAULT NULL,
  `Room_Amount` int(11) NOT NULL,
  `Status` varchar(10) NOT NULL,
  `Request` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `booking`
--

INSERT INTO `booking` (`Booking_ID`, `Room_ID`, `Customer_ID`, `Check_In`, `Check_Out`, `Number_of_Rooms`, `Room_Amount`, `Status`, `Request`) VALUES
(185, 1, 36, '2016-11-14', '2016-11-18', 1, 4000, 'Pending', ''),
(186, 1, 39, '2016-11-09', '2016-11-10', 1, 1000, 'Booked', ''),
(187, 2, 39, '2016-11-11', '2016-11-13', 1, 1800, 'Pending', ''),
(188, 3, 38, '2016-11-14', '2016-11-18', 1, 3200, 'Pending', ''),
(189, 2, 36, '2016-11-19', '2016-11-21', 1, 1800, 'Pending', ''),
(190, 1, 40, '2016-11-22', '2016-11-25', 1, 3000, 'Pending', ''),
(191, 1, 41, '2016-11-27', '2016-11-30', 1, 3000, 'Pending', '');

-- --------------------------------------------------------

--
-- Table structure for table `car_hire`
--

CREATE TABLE `car_hire` (
  `Car_ID` int(11) NOT NULL,
  `Customer_ID` int(11) NOT NULL,
  `Booking_ID` int(11) NOT NULL,
  `Selected_Car` varchar(15) NOT NULL,
  `From_Date` date NOT NULL,
  `To_Date` date NOT NULL,
  `Car_Charges` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `car_hire`
--

INSERT INTO `car_hire` (`Car_ID`, `Customer_ID`, `Booking_ID`, `Selected_Car`, `From_Date`, `To_Date`, `Car_Charges`) VALUES
(4, 36, 185, 'Corolla', '2016-11-14', '2016-11-17', 1110),
(11, 36, 189, 'BMW', '2016-11-19', '2016-11-21', 900),
(14, 36, 189, 'Mercedes', '2016-11-19', '2016-11-20', 500);

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `Customer_ID` int(11) NOT NULL,
  `First_Name` varchar(15) NOT NULL,
  `Last_Name` varchar(15) NOT NULL,
  `Email` varchar(25) NOT NULL,
  `Password` varchar(10) NOT NULL,
  `Address` varchar(100) NOT NULL,
  `Country` varchar(10) NOT NULL,
  `Cell_Number` int(20) NOT NULL,
  `pp` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`Customer_ID`, `First_Name`, `Last_Name`, `Email`, `Password`, `Address`, `Country`, `Cell_Number`, `pp`) VALUES
(36, 'Asad', 'Ali', 'asad@gmail.com', '444444', 'house # 12', 'Pakistan', 2147483647, 'Resized-VKHV8.jpg'),
(38, 'Saad', 'Ali', 'saad@gmail.com', '909090', 'flat # 43 erum avenue', 'Pakistan', 2136649631, 'Resized-NCF2C.jpg'),
(39, 'Saroosh', 'Ali', 'saroosh@gmail.com', '676767', 'house # 78', 'Palestine', 21, 'Resized-91MC8.jpg'),
(40, 'Muhammad', 'Mujeeb', 'mujeeb@yahoo.com', '131313', 'house # 11', 'Pakistan', 2147483647, ''),
(41, 'Ali', 'Farzan', 'ali@yahoo.com', 'alifarzan', 'house # 90', 'Turkey', 2147483647, 'IMG-20160324-WA0027.jpg_flipped(1).jpg'),
(42, 'Muzammil', 'Ahmed', 'muzammil31@yahoo.com', '987654', 'house # 92 KoderLabs', 'Pakistan', 2147483647, ''),
(43, ' Saad', 'Siddiqui', 'saad@hotmail.com', '676767', 'flat # 67 Haroon Apartment', 'Pakistan', 2147483647, ''),
(44, 'Junaid', 'Ahmed', 'junaid@hotmail.com', '129056', 'house # 67', 'Indonesia', 2147483647, ''),
(45, 'Moiz', 'Ahmed', 'moiz@yahoo.com', '111111', 'flat # 4', 'Pakistan', 2136649631, ''),
(46, 'Ahmed', 'Baig', 'ahmed@outlook.com', '898989', 'flat # 56', 'Pakistan', 21, ''),
(47, 'Faizan', 'Ahmed', 'faizan@gmail.com', '808080', 'house # 106', 'Pakistan', 21, ''),
(48, 'Fardan', 'Akhtar', 'fardan@gmail.com', '454545', 'house # 30', 'Israel', 2147483647, '');

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE `feedback` (
  `Visitor_ID` int(11) NOT NULL,
  `Name` varchar(15) NOT NULL,
  `Email` varchar(20) NOT NULL,
  `Message` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`Visitor_ID`, `Name`, `Email`, `Message`) VALUES
(2, 'Haroon', 'haroon123@gmail.com', 'Hi Haroon is here!'),
(3, 'Muzammil', 'muzammil@yahoo.com', 'Hi! My Name is Muzammil...');

-- --------------------------------------------------------

--
-- Table structure for table `room`
--

CREATE TABLE `room` (
  `Room_ID` int(11) NOT NULL,
  `Room_Name` varchar(10) NOT NULL,
  `Room_Price` bigint(20) NOT NULL,
  `Total_Rooms` int(11) NOT NULL,
  `Room_Images` text NOT NULL,
  `Feature1` varchar(200) NOT NULL,
  `Feature2` varchar(200) NOT NULL,
  `Feature3` varchar(200) NOT NULL,
  `Feature4` varchar(200) NOT NULL,
  `Entertainment1` varchar(200) NOT NULL,
  `Entertainment2` varchar(200) NOT NULL,
  `Entertainment3` varchar(200) NOT NULL,
  `Entertainment4` varchar(200) NOT NULL,
  `Housekeeping1` varchar(200) NOT NULL,
  `Housekeeping2` varchar(200) NOT NULL,
  `Housekeeping3` varchar(200) NOT NULL,
  `Housekeeping4` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `room`
--

INSERT INTO `room` (`Room_ID`, `Room_Name`, `Room_Price`, `Total_Rooms`, `Room_Images`, `Feature1`, `Feature2`, `Feature3`, `Feature4`, `Entertainment1`, `Entertainment2`, `Entertainment3`, `Entertainment4`, `Housekeeping1`, `Housekeeping2`, `Housekeeping3`, `Housekeeping4`) VALUES
(1, 'DELUXE', 1000, 10, 'room_images/pic.jpg', 'Class Triple Bed', 'Electronic key card access', 'Air conditioning with individual controls', 'In-room tea and coffee', 'DVD player', '32-inch LED TV', 'Free WiFi', 'TV', 'Complimentary fruit basket', 'Complimentary coffee set', 'Complimentary local newspaper', 'Turn down service'),
(2, 'DIAMOND', 900, 10, 'room_images/hotels_unionsquare_rooms_deluxe.jpg', 'Class Double Bed', 'Electronic key card access', 'Air conditioning with individual controls', 'In-room tea and coffee', 'DVD player', '28-inch LED TV', 'Free WiFi', 'TV', 'Complimentary fruit basket', 'Complimentary coffee set', 'Complimentary local newspaper', 'Turn down service'),
(3, 'SILVER', 800, 10, 'room_images/HRH-Deluxe-Twin-610x320.jpg', 'Class Single Bed', 'Electronic key card access', 'Air condition', 'In-room tea and coffee', 'DVD player', '24-inch LCD TV', 'IDD Call', 'TV', 'Complimentary fruit basket', 'Complimentary coffee set', 'Complimentary local newspaper', 'Turn down service');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`Admin_ID`);

--
-- Indexes for table `booking`
--
ALTER TABLE `booking`
  ADD PRIMARY KEY (`Booking_ID`),
  ADD KEY `Room_ID` (`Room_ID`),
  ADD KEY `Customer_ID` (`Customer_ID`);

--
-- Indexes for table `car_hire`
--
ALTER TABLE `car_hire`
  ADD PRIMARY KEY (`Car_ID`),
  ADD KEY `Customer_ID` (`Customer_ID`),
  ADD KEY `Booking_ID` (`Booking_ID`);

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`Customer_ID`);

--
-- Indexes for table `feedback`
--
ALTER TABLE `feedback`
  ADD PRIMARY KEY (`Visitor_ID`);

--
-- Indexes for table `room`
--
ALTER TABLE `room`
  ADD PRIMARY KEY (`Room_ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `Admin_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `booking`
--
ALTER TABLE `booking`
  MODIFY `Booking_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=192;
--
-- AUTO_INCREMENT for table `car_hire`
--
ALTER TABLE `car_hire`
  MODIFY `Car_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
--
-- AUTO_INCREMENT for table `customer`
--
ALTER TABLE `customer`
  MODIFY `Customer_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=50;
--
-- AUTO_INCREMENT for table `feedback`
--
ALTER TABLE `feedback`
  MODIFY `Visitor_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `room`
--
ALTER TABLE `room`
  MODIFY `Room_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `booking`
--
ALTER TABLE `booking`
  ADD CONSTRAINT `booking_ibfk_1` FOREIGN KEY (`Customer_ID`) REFERENCES `customer` (`Customer_ID`),
  ADD CONSTRAINT `booking_ibfk_2` FOREIGN KEY (`Room_ID`) REFERENCES `room` (`Room_ID`),
  ADD CONSTRAINT `booking_ibfk_3` FOREIGN KEY (`Customer_ID`) REFERENCES `customer` (`Customer_ID`) ON DELETE CASCADE;

--
-- Constraints for table `car_hire`
--
ALTER TABLE `car_hire`
  ADD CONSTRAINT `car_hire_ibfk_1` FOREIGN KEY (`Customer_ID`) REFERENCES `customer` (`Customer_ID`),
  ADD CONSTRAINT `car_hire_ibfk_2` FOREIGN KEY (`Booking_ID`) REFERENCES `booking` (`Booking_ID`),
  ADD CONSTRAINT `car_hire_ibfk_3` FOREIGN KEY (`Customer_ID`) REFERENCES `customer` (`Customer_ID`) ON DELETE CASCADE,
  ADD CONSTRAINT `car_hire_ibfk_4` FOREIGN KEY (`Booking_ID`) REFERENCES `booking` (`Booking_ID`) ON DELETE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
