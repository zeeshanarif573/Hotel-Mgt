--
-- Database: `hotel`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `Admin_ID` int(11) NOT NULL,
  `Name` varchar(20) NOT NULL,
  `Username` varchar(25) NOT NULL,
  `Password` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`Admin_ID`, `Name`, `Username`, `Password`) VALUES
(4, 'zeeshan', 'zeeshanarif573@gmail.com', 2222),
(5, 'asad', 'asad@yahoo.com', 5555),
(6, 'saad', 'saad@hotmail.com', 2222),
(7, 'Shayan', 'shayan@gmail.com', 6767),
(8, 'Ahsan', 'ahsan@yahoo.com', 4444);

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `Customer_ID` int(11) NOT NULL,
  `Email` varchar(30) NOT NULL,
  `Password` int(11) NOT NULL,
  `Name` varchar(30) NOT NULL,
  `Address` varchar(100) NOT NULL,
  `Nationality` varchar(15) NOT NULL,
  `Check_In` date NOT NULL,
  `Check_Out` date NOT NULL,
  `Room_Type` varchar(6) NOT NULL,
  `Num_Of_Rooms` varchar(3) NOT NULL,
  `Room_Amount` int(11) NOT NULL,
  `Selected_Car` varchar(15) NOT NULL,
  `From_Date` date NOT NULL,
  `To_Date` date NOT NULL,
  `Car_Amount` int(11) NOT NULL,
  `Total_Amount` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`Customer_ID`, `Email`, `Password`, `Name`, `Address`, `Nationality`, `Check_In`, `Check_Out`, `Room_Type`, `Num_Of_Rooms`, `Room_Amount`, `Selected_Car`, `From_Date`, `To_Date`, `Car_Amount`, `Total_Amount`) VALUES
(17, 'mujeeb@yahoo.com', 1313, 'Mujeeb', 'flat # 5', 'pakistani', '2016-11-03', '2016-11-25', 'Double', '2', 0, 'Civic', '2016-10-18', '2016-10-15', 0, 0),
(18, 'asad@gmail.com', 7878, 'asad', 'flat # 3', 'indian', '2016-10-14', '2016-10-23', 'Double', '1', 0, '', '0000-00-00', '0000-00-00', 0, 0),
(22, 'farhan@gmail.com', 1111, 'Farhan', 'flat # 4', 'palestine', '2016-10-06', '2016-10-27', 'Single', '7', 0, 'City', '2016-10-06', '2016-10-19', 0, 0),
(23, 'junaid@hotmail.com', 1010, 'junaid', '', '', '0000-00-00', '0000-00-00', '', '', 0, '', '0000-00-00', '0000-00-00', 0, 0),
(24, 'saroosh@gmail.com', 4444, 'saroosh', '', '', '0000-00-00', '0000-00-00', '', '', 0, '', '0000-00-00', '0000-00-00', 0, 0),
(25, 'moiz@yahoo.com', 11111, 'moiz', '', '', '0000-00-00', '0000-00-00', '', '', 0, '', '0000-00-00', '0000-00-00', 0, 0),
(26, 'qamar@yahoo.com', 7676, 'qamar', 'flat # 21', 'iraqi', '2016-10-05', '2016-10-22', 'Single', '4', 0, 'Audi', '2016-10-13', '2016-10-20', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE `feedback` (
  `Visitor_ID` int(11) NOT NULL,
  `Name` varchar(25) NOT NULL,
  `Email` varchar(20) NOT NULL,
  `Message` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`Visitor_ID`, `Name`, `Email`, `Message`) VALUES
(1, 'Shayan', 'shayan@yahoo.com', 'My name is Shayan');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`Admin_ID`);

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`Customer_ID`);

--
-- Indexes for table `feedback`
--
ALTER TABLE `feedback`
  ADD PRIMARY KEY (`Visitor_ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `Admin_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `customer`
--
ALTER TABLE `customer`
  MODIFY `Customer_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;
--
-- AUTO_INCREMENT for table `feedback`
--
ALTER TABLE `feedback`
  MODIFY `Visitor_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
