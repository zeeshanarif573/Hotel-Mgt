--
-- Database: `hotel`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `Admin_ID` int(11) NOT NULL,
  `Name` varchar(20) NOT NULL,
  `Username` varchar(25) NOT NULL,
  `Password` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`Admin_ID`, `Name`, `Username`, `Password`) VALUES
(5, 'asad', 'asad@yahoo.com', 5555),
(6, 'saad', 'saad@hotmail.com', 2222),
(9, 'Rehan', 'rehan@gmail.com', 1111);

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `Customer_ID` int(11) NOT NULL,
  `Email` varchar(30) NOT NULL,
  `Password` int(11) NOT NULL,
  `Name` varchar(30) NOT NULL,
  `Address` varchar(100) NOT NULL,
  `Nationality` varchar(15) NOT NULL,
  `Check_In` date NOT NULL,
  `Check_Out` date NOT NULL,
  `Room_Type` varchar(6) NOT NULL,
  `Num_Of_Rooms` varchar(3) NOT NULL,
  `Room_Amount` int(11) NOT NULL,
  `Selected_Car` varchar(15) NOT NULL,
  `Days` varchar(2) NOT NULL,
  `From_Date` date NOT NULL,
  `To_Date` date NOT NULL,
  `Car_Amount` int(11) NOT NULL,
  `Total_Amount` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`Customer_ID`, `Email`, `Password`, `Name`, `Address`, `Nationality`, `Check_In`, `Check_Out`, `Room_Type`, `Num_Of_Rooms`, `Room_Amount`, `Selected_Car`, `Days`, `From_Date`, `To_Date`, `Car_Amount`, `Total_Amount`) VALUES
(17, 'mujeeb@yahoo.com', 1313, 'Mujeeb', 'house # 104', 'pakistani', '2016-10-01', '2016-10-05', 'Single', '3', 7500, 'Ford', '3', '2016-10-04', '2016-10-07', 1200, 0),
(18, 'asad@gmail.com', 7878, 'asad', 'flat # 3', 'indian', '2016-10-14', '2016-10-23', 'Double', '1', 0, '', '', '0000-00-00', '0000-00-00', 0, 0),
(27, 'fardan@gmail.com', 8989, 'fardan', 'house # 41', 'turkish', '2016-10-12', '2016-10-21', 'Double', '4', 14000, 'Mercedes', '7', '2016-10-12', '2016-10-19', 3500, 17500);

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE `feedback` (
  `Visitor_ID` int(11) NOT NULL,
  `Name` varchar(25) NOT NULL,
  `Email` varchar(20) NOT NULL,
  `Message` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`Visitor_ID`, `Name`, `Email`, `Message`) VALUES
(1, 'Shayan', 'shayan@yahoo.com', 'My name is Shayan'),
(2, 'Mustafa', 'mustafa@yahoo.com', 'My Name is Mustafa');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`Admin_ID`);

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`Customer_ID`);

--
-- Indexes for table `feedback`
--
ALTER TABLE `feedback`
  ADD PRIMARY KEY (`Visitor_ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `Admin_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `customer`
--
ALTER TABLE `customer`
  MODIFY `Customer_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;
--
-- AUTO_INCREMENT for table `feedback`
--
ALTER TABLE `feedback`
  MODIFY `Visitor_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
